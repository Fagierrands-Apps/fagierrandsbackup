#!/usr/bin/env bash
set -o errexit

echo "🚀 Starting Render deployment..."

# Navigate to Django project directory
cd fagierrandsbackup

# Install dependencies
pip install -r requirements.txt

# Collect static files
python manage.py collectstatic --noinput

# Run migrations
python manage.py migrate

echo "✅ Deployment complete!"
